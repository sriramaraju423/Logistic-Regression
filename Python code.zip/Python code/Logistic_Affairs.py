#!/usr/bin/env python
# coding: utf-8

# In[5]:


import pandas as pd
import seaborn as sb


# In[6]:


affairs = pd.read_csv(r"C:\Users\srira\Desktop\Ram\Data science\Course - Assignments\Module 9 - Logistic Regression\Datasets\Affairs.csv")
affairs.columns
affairs


# In[7]:


sb.countplot(affairs['avgmarr'],data=affairs,palette='hls')


# In[8]:


sb.countplot(affairs['hapavg'],data=affairs,palette='hls')


# In[9]:


sb.countplot(affairs['vryunhap'],data=affairs,palette='hls')


# In[10]:


pd.crosstab(affairs['avgmarr'],affairs['hapavg']).plot(kind='bar')


# In[11]:


affairs['vryunhap'].value_counts()+affairs['unhap'].value_counts()+affairs['avgmarr'].value_counts()+affairs['hapavg'].value_counts()+affairs['vryhap'].value_counts()


# #### Just cross checking whether the columns avgmarr and hapavg are related to happiness of the data because names are quite confusing

# In[12]:


affairs.iloc[:,0]


# In[13]:


affairs


# In[14]:


affairs['naffairs'].value_counts()


# #### Our output interested event is binary data either 0 or 1 and not no of affairs so we are converting the >0 to 1

# In[15]:


affairs_count = affairs['naffairs'].value_counts()


# In[16]:


affairs


# In[17]:


affairs.drop(affairs.columns[0],inplace=True, axis = 1)


# In[18]:


i = 0
while i<len(affairs['naffairs'].values):
    if(affairs['naffairs'].values[i]>0):
        affairs['naffairs'][i] = 1
    i += 1    


# In[19]:


affairs['kids'].value_counts()


# In[20]:


affairs.isnull().sum()


# #### No null values we can proceed with existing dataset

# In[21]:


sb.boxplot(x=affairs['naffairs'],y=affairs['kids'], data = affairs, palette='hls')


# In[22]:


pd.crosstab(affairs['naffairs'],affairs['kids']).plot(kind='bar')


# In[23]:


pd.crosstab(affairs['naffairs'],affairs['yrsmarr6']).plot(kind='bar')


# In[24]:


from sklearn.model_selection import train_test_split
affairs_train,affairs_test = train_test_split(affairs,test_size=0.3)


# In[25]:


#Building model
from sklearn.linear_model import LogisticRegression
x_actual = affairs.iloc[:,1:]
x = affairs_train.iloc[:,1:]
x_test = affairs_test.iloc[:,1:]
y = affairs_train.iloc[:,0]
y_test = affairs_test.iloc[:,0]
affairs_model = LogisticRegression().fit(x,y)
affairs_model


# In[26]:


y_pred_total = affairs_model.predict(x_actual)
y_pred = affairs_model.predict(x)
accuracy = sum(y==y_pred)/affairs_train.shape[0]
accuracy


# In[27]:


y_pred_test = affairs_model.predict(x_test)
accuracy = sum(y_test==y_pred_test)/affairs_test.shape[0]
accuracy


# In[28]:


from sklearn.metrics import confusion_matrix
confusion_matrix = confusion_matrix(y,y_pred)
confusion_matrix


# In[36]:


affairs['y_pred'] = y_pred_total
affairs
y_prob = affairs_model.predict_proba(x)
y_prob


# In[35]:


affairs.columns
import os
os.getcwd()
y.value_counts()


# In[34]:


affairs.to_csv('affairs_predictors.csv')

