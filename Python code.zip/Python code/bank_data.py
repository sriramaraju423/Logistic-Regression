#!/usr/bin/env python
# coding: utf-8

# In[3]:


import pandas as pd


# In[4]:


bank_data = pd.read_csv(r"C:\Users\srira\Desktop\Ram\Data science\Course - Assignments\Module 9 - Logistic Regression\Datasets\bank_data.csv")
bank_data


# In[9]:


bank_data['default'].value_counts()


# In[62]:


bank_data.shape


# In[6]:


bank_data.isnull().sum()


# In[11]:


import seaborn as sb
sb.countplot(bank_data['y'],data = bank_data, palette='hls')


# In[12]:


sb.countplot(bank_data['default'],data = bank_data, palette='hls')


# In[13]:


sb.countplot(bank_data['housing'],data = bank_data, palette='hls')


# In[14]:


sb.countplot(bank_data['loan'],data = bank_data, palette='hls')


# In[18]:


sb.countplot(bank_data['con_cellular'],data = bank_data, palette='hls')


# In[19]:


pd.crosstab(bank_data['y'],bank_data['default']).plot(kind='bar')


# In[20]:


pd.crosstab(bank_data['y'],bank_data['housing']).plot(kind='bar')


# In[21]:


pd.crosstab(bank_data['y'],bank_data['married']).plot(kind='bar')


# In[22]:


pd.crosstab(bank_data['y'],bank_data['single']).plot(kind='bar')


# In[23]:


pd.crosstab(bank_data['y'],bank_data['joblue.collar']).plot(kind='bar')


# In[24]:


pd.crosstab(bank_data['y'],bank_data['joretired']).plot(kind='bar')


# In[25]:


pd.crosstab(bank_data['y'],bank_data['joentrepreneur']).plot(kind='bar')


# In[26]:


pd.crosstab(bank_data['y'],bank_data['jomanagement']).plot(kind='bar')


# In[27]:


sb.boxplot(x=bank_data['y'],y=bank_data['age'],data = bank_data, palette='hls')


# In[28]:


sb.boxplot(x=bank_data['y'],y=bank_data['balance'],data = bank_data, palette='hls')


# #### There are decent outliers, first let's try building model and check accuracy then we will handle outliers if the model is very bad

# In[45]:


#model building
from sklearn.model_selection import train_test_split
bank_data_train,bank_data_test = train_test_split(bank_data,test_size = 0.3)

x = bank_data_train.iloc[:,:-1]
y = bank_data_train.iloc[:,-1]
from sklearn.linear_model import LogisticRegression
bank_data_train_model = LogisticRegression().fit(x,y)
bank_data_train_model


# In[68]:


y_pred = bank_data_train_model.predict(x)
y_pred


# In[47]:


from sklearn.metrics import confusion_matrix
confusion_matrix = confusion_matrix(y,y_pred)
confusion_matrix


# In[48]:


accuracy = sum(y==y_pred)/bank_data_train.shape[0]
accuracy


# In[50]:


x_test = bank_data_test.iloc[:,:-1]
y_test = bank_data_test.iloc[:,-1]
y_pred_test = bank_data_train_model.predict(x_test)
y_pred_test
accuracy = sum(y_test==y_pred_test)/bank_data_test.shape[0]
accuracy


# In[67]:


import numpy as np
y_pred_final = np.concatenate((y_pred,y_pred_test),axis=None)
y_pred_final


# In[69]:


bank_data['y_pred'] = y_pred_final


# In[70]:


bank_data.to_csv('bank_data_predict.csv')


# In[5]:


bank_data.columns

