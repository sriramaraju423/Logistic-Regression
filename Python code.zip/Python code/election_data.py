#!/usr/bin/env python
# coding: utf-8

# In[33]:


import pandas as pd
import seaborn as sb
from sklearn.linear_model import LogisticRegression


# In[3]:


election_data = pd.read_csv(r"C:\Users\srira\Desktop\Ram\Data science\Course - Assignments\Module 9 - Logistic Regression\Datasets\election_data.csv")
election_data


# In[4]:


# election_data.drop(election_data.columns[0], inplace=True, axis=1) - If column name is not given
election_data.drop(columns='Election-id', inplace=True, axis=1)


# In[5]:


election_data.drop([0], inplace=True)
election_data


# ### EDA

# #### 'Popularity Rank' is categorical and need to set dummy variables

# In[19]:


dummies = pd.get_dummies(election_data['Popularity Rank'])
dummies.columns = dummies.columns.astype(str) 
dummies


# In[20]:


election_data_dummies = pd.concat([election_data,dummies], axis=1)
election_data_dummies.drop(['Popularity Rank'], inplace=True, axis=1)
election_data_dummies


# #### EDA: checking null values

# In[8]:


election_data_dummies.isnull().sum()


# #### No null values so RRR technique is not required

# In[22]:


#Drawing plot for EDA
sb.countplot(election_data_dummies['Result'], data=election_data_dummies, palette='hls')
sb.countplot(election_data_dummies['1.0'], data=election_data_dummies, palette='hls')
sb.countplot(election_data_dummies['2.0'], data=election_data_dummies, palette='hls')
sb.countplot(election_data_dummies['3.0'], data=election_data_dummies, palette='hls')
sb.countplot(election_data_dummies['4.0'], data=election_data_dummies, palette='hls')


# In[26]:


pd.crosstab(election_data_dummies['Result'],election_data_dummies['1.0']).plot(kind='bar')
pd.crosstab(election_data_dummies['Result'],election_data_dummies['2.0']).plot(kind='bar')
pd.crosstab(election_data_dummies['Result'],election_data_dummies['3.0']).plot(kind='bar')
pd.crosstab(election_data_dummies['Result'],election_data_dummies['4.0']).plot(kind='bar')


# #### From the count plot it's clear that candidates having priority ranking 1 & 2 won the election 3 & 4 they lost the election

# In[28]:


sb.boxplot(x='1.0', y='Amount Spent', data=election_data_dummies, palette='hls')


# In[29]:


sb.boxplot(x='2.0', y='Amount Spent', data=election_data_dummies, palette='hls')


# In[30]:


sb.boxplot(x='3.0', y='Amount Spent', data=election_data_dummies, palette='hls')


# In[31]:


sb.boxplot(x='4.0', y='Amount Spent', data=election_data_dummies, palette='hls')


# In[34]:


#Building model
x = election_data_dummies.iloc[:,1:]
y = election_data_dummies.iloc[:,0]
election_data_logistic_model = LogisticRegression().fit(x,y)
election_data_logistic_model


# In[35]:


y_pred = election_data_logistic_model.predict(x)
y_pred


# In[36]:


accuracy = sum(y==y_pred)/election_data_dummies.shape[0]
accuracy


# In[37]:


#confusion matrix
from sklearn.metrics import confusion_matrix
confusion_matrix = confusion_matrix(y,y_pred)
confusion_matrix


# In[43]:


election_data_dummies['y_pred'] = y_pred
election_data_dummies.to_csv('election_data_pred.csv')


# In[39]:


from sklearn.model_selection import train_test_split
train_election_data, test_election_data = train_test_split(election_data_dummies,test_size=0.3)


# In[44]:


x_train = train_election_data.iloc[:,1:]
y_train = train_election_data.iloc[:,0]
election_data_logistic_train_model = LogisticRegression().fit(x_train,y_train)
election_data_logistic_train_model
y_train_pred = election_data_logistic_train_model.predict(x_train)
y_train_pred
accuracy = sum(y_train==y_train_pred)/train_election_data.shape[0]
accuracy


# In[45]:


x_test = test_election_data.iloc[:,1:]
y_test = test_election_data.iloc[:,0]
election_data_logistic_test_model = LogisticRegression().fit(x_test,y_test)
election_data_logistic_test_model
y_test_pred = election_data_logistic_test_model.predict(x_test)
y_test_pred
accuracy = sum(y_test==y_test_pred)/test_election_data.shape[0]
accuracy


# #### We cannot actually rely on the train and test accuracy for this dataset as the size is too small
